// This header is NOT generated.

#ifndef _CHILKAT_INT64_DEF
#define _CHILKAT_INT64_DEF

// All of this has been moved to be part of ck_inttypes.h

#endif // _CHILKAT_INT64_DEF

